"""Updater-logic v1 entrypoint.

The bootstrap (`windows_updater.exe`) imports this module from
`<install_dir>/updater-logic/v1/run.py` when the active pointer resolves to
v1, and calls `run(args)` with the legacy argv tail. v1 is intentionally
a thin shim into the in-EXE legacy body via `legacy_v1_dispatch`; later
versions will move the body fully on-disk.
"""

from windows_updater_pkg.main import legacy_v1_dispatch


def run(args: list) -> int:
    return legacy_v1_dispatch(args)


def probe() -> bool:
    """Lightweight probe used by the bootstrap's verify stage. Imports
    the in-EXE entrypoint and returns True if it resolves."""
    return callable(legacy_v1_dispatch)
